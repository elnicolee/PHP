<?php $this->load->view('template_home/_head'); ?>
<!-- navbar -->
<?php $this->load->view('template_home/_body'); ?>
<!-- content -->

<!-- end content -->
<!-- footer -->
<?php $this->load->view('template_home/_footer'); ?>