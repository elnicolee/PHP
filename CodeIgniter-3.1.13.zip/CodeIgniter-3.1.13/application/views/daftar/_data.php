<script>
model.masterModel = {
    id: 0,
    nama: "",
    kelas: "",
    alamat: "",
}
var material = {
    title: "Data Satuan",
    Recordmaterial: ko.mapping.fromJS(model.masterModel),
    Listmaterial: ko.observableArray([]),
    Mode: ko.observable(''),
    DataFilter: ko.observableArray(['SATUAN']),
    FilterText: ko.observable(''),
    FilterValue: ko.observable('nama'),
}
material.back = function(tab) {
    material.Mode('');
    material.grid.ajax.reload(null, false);
    // $("input[name=txtkategoriId]").attr("disabled", false);
    ko.mapping.fromJS(model.masterModel, material.Recordmaterial);
    model.activetab(tab);
}

material.selectdata = function(id) {
    model.Processing(true);
    ajaxPost("<?php echo site_url('C_daftar/getDataSelect') ?>", {
        id: id
    }, function(res) {
        console.log(res[0]);
        material.back(0);
        $("input[name=txtid").attr("disabled", true);
        ko.mapping.fromJS(res[0], material.Recordmaterial);
        material.Mode("Update");
        model.Processing(false);
    });
}

material.save = function() {
    model.Processing(true);
    var val = material.Recordmaterial;
    swal({
        title: "Perhatian",
        text: "Anda akan simpan data ini?",
        type: "info",
        className: 'animate__animated animate__fadeInUp',
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes!",
        cancelButtonText: "No!",
        closeOnConfirm: false,
        showLoaderOnConfirm: true,
        // timer: 1000,
    }, function(isConfirm) {
        if (isConfirm) {
            if (material.Recordmaterial.nama() == "") {
                setTimeout(function() {
                    swal("Peringatan!", "Data Harap diisi Dengan Benar!", "warning");
                }, );
            } else {
                // end else
                if (showLoaderOnConfirm = true) {

                    var url = "<?php echo base_url('C_daftar/save') ?>";

                    if (material.Mode() === 'Update')
                        url = "<?php echo base_url('C_daftar/update') ?>";
                    ajaxPost(url, material.Recordmaterial,
                        function(res) {
                            console.log(res.result);
                            if (res.result == true || material.Mode() == "Update") {
                                if (res.result == true) {
                                    material.back(0);
                                    setTimeout(function() {
                                        swal({
                                            title: "Good job!",
                                            text: "Data Berhasil di input!",
                                            icon: "success",
                                            /* sukses simpan / update */
                                        });
                                    }, 2000);
                                }
                                if (material.Mode() == "Update") {
                                    material.back(1);
                                    setTimeout(function() {
                                        swal({
                                            title: "Good job!",
                                            text: "Data Berhasil di ubah!",
                                            icon: "success",
                                            /* sukses simpan / update */
                                        });
                                    }, 2000);
                                }

                            }
                        });
                }
            }
        }
        model.Processing(false);
    }); // END isconfirm swal
    model.Processing(false);
}
material.remove = function(id) {
    swal({
        title: "Are you sure?",
        text: "Delete <?= $title; ?>!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes!",
        cancelButtonText: "No!",
        closeOnConfirm: false,
    }, function(isConfirm) {
        if (isConfirm) {
            ajaxPost("<?php echo base_url('C_daftar/delete') ?>", {
                id: id
            }, function(res) {
                material.back(1);
                swal("Deleted!", "Deleted <?= $title; ?>", "success");
            });
        }
    });
}
</script>

<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->


<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-1">
                <div class="col-sm-6">
                    <!-- <h1 class="m-0 text-dark">Dashboard v2</h1> -->
                </div><!-- /.col -->
                <!-- <div class="col-sm-6"> -->
                <ol class="breadcrumb">


                    <!-- <li class="breadcrumb-item active">Table editable</li> -->
                </ol>
                <!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="container">
        <div class="row">
            <!-- ============================================================== -->
            <!-- Right sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- End Right sidebar -->
            <!-- ============================================================== -->

            <div class="col-md-12">
                <div class="card card card-body p-b-0" data-bind="with:material">
                    <div class="col-md-5 align-self-left">
                        <h3 class="text-themecolor" data-bind='text: title'></h3>
                    </div>
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs customtab" id="tabnavform">
                        <li class="nav-item"><a class="nav-link active" href="#tabform" data-toggle="tab">Form</a></li>
                        <li class="nav-item"><a class="nav-link" href="#tablist" data-toggle="tab">List</a></li>
                    </ul>
                    <!-- End Nav tabs -->
                    <div class="content tab-content" id="tabnavform-content">


                        <div class="tab-pane active" id="tabform">
                            <div class="card-body p-20 animated fadeIn m">
                                <div class="row p-t-23 margMin">
                                    <div class="col-md-12 margMin">
                                        <div class="form-group ">
                                            <button class="btn btn-sm btn-primary"
                                                data-bind="click:function(){back(1);}, visible: Mode() == 'Update'"
                                                data-toggle="tooltip" data-placement="top"
                                                data-original-title="Kembali"><span
                                                    class="glyphicon glyphicon-chevron-left"></span>
                                                << Kembali</button>

                                                    <button class="btn btn-sm btn-info" data-bind="click:save"
                                                        data-toggle="tooltip" data-placement="top"
                                                        data-original-title="simpan"><span
                                                            class="glyphicon glyphicon-floppy-disk"></span> <span
                                                            data-bind="data-original-title:Mode"><i
                                                                class="fa fa-save"></i> Simpan</span></button>

                                                    <button class="btn btn-sm btn-danger"
                                                        data-bind="click:function(){remove(Recordmaterial.id());}, visible: Mode() == 'Update'"><span
                                                            class="glyphicon glyphicon-trash"></span><i
                                                            class="fa fa-trash"></i> Hapus</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="row p-t-23 " data-bind="with:Recordmaterial">

                                    <div class="col-md-6 margMin">
                                        <div class="form-group ">
                                            <label class="control-label">nama</label>
                                            <input type="text" name="txtnama" data-bind="value:nama" id="" required=""
                                                class="form-control" placeholder="nama">
                                        </div>
                                    </div>

                                    <div class="col-md-6 margMin">
                                        <div class="form-group ">
                                            <label class="control-label">kelas</label>
                                            <input type="text" name="txtkelas" data-bind="value:kelas" id="" required=""
                                                class="form-control" placeholder="kelas">
                                        </div>
                                    </div>

                                    <div class="col-md-6 margMin">
                                        <div class="form-group ">
                                            <label class="control-label">alamat</label>
                                            <input type="text" name="txtalamat" data-bind="value:alamat" id=""
                                                required="" class="form-control" placeholder="alamat">
                                        </div>
                                    </div>

                                    <!-- <div class="col-md-6 margMin">
                                        <div class="form-group ">
                                            <label class="control-label">alamat</label>
                                            <input type="text" name="txtalamat" data-bind="value:alamat" id=""
                                                required="" class="form-control" placeholder="alamat">
                                        </div>
                                    </div> -->

                                </div>
                            </div>
                        </div>



                        <div class="tab-pane" id="tablist">
                            <div class="card-body p-20" data-bind="with:material">
                                <div class="row p-t-23 ">
                                    <div class="col-md-12 ">
                                        <div class="table-responsive m-t-40 animated fadeIn">
                                            <table id="myTable" width="100%"
                                                class="table table-bordered table-striped ">
                                                <thead>
                                                    <tr>
                                                        <th>id</th>
                                                        <th>nama</th>
                                                        <th>kelas</th>
                                                        <th>alamat</th>
                                                        <th>ACTION</th>
                                                    </tr>
                                                </thead>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
            </div>
        </div>
    </div>
</div>



<script>
$(document).ready(function() {
    model.Processing(true);
    material.grid = $("#myTable").DataTable({
        "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo base_url('C_daftar/getData') ?>",
            "type": "POST",
            "data": function(d) {
                d['filtervalue'] = material.FilterValue();
                d['filtertext'] = material.FilterText();
                return d;
            },
            "dataSrc": function(json) {
                // json.draw = 1;
                json.recordsTotal = json.RecordsTotal;
                json.recordsFiltered = json.RecordsFiltered;

                if (json.Data)
                    return json.Data;
                else
                    return [];
            },
        },
        "searching": false,
        "columns": [{
                "data": "id"
            },
            {
                "data": "nama"
            },
            {
                "data": "kelas"
            },
            {
                "data": "alamat"
            },
            {
                "data": "id",
                "render": function(data, type, full, meta) {
                    return "<button class='btn btn-sm btn-info' onClick='material.selectdata(\"" +
                        data +
                        "\")'><i class='fa fa-edit'></i></button> &nbsp; <button  id='sa-warning' class='btn btn-sm btn-danger' onClick='material.remove(\"" +
                        data + "\")' id='sa-warning' ><i class='fa fa-trash'></i></button>";
                }
            }
        ],
    });
    model.Processing(false);
});
</script>