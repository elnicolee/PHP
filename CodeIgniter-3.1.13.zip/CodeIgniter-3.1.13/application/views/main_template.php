<?php $this->load->view('template_regis/_head'); ?>
<!-- navbar -->
<?php $this->load->view('template_regis/_body'); ?>
<!-- content -->

<!-- end content -->
<!-- footer -->
<?php $this->load->view('template_regis/_footer'); ?>