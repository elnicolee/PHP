<body>

  <div class="hero_area">

    <div class="hero_bg_box">
      <div class="bg_img_box">
        <img src="images/hero-bg.png" alt="">
      </div>
    </div>

    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <span>
              K
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  ">
              <li class="nav-item active">
                <a class="nav-link" href="#home">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#service"> Services</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">Requirements</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#why">Why Us</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#team">Team</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="registration"> <i class="fa fa-user" aria-hidden="true"></i> Registration</a>
              </li>
              <form class="form-inline">
               
              </form>
            </ul>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class="slider_section " id="home">
      <div id="customCarousel1" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="container ">
              <div class="row">
                <div class="col-md-6 ">
                  <div class="detail-box">
                    <h1>
                      Kazuya <br>
                      Media Indonesia
                    </h1>
                    <p>
                    Jasa Pembuatan Website Dan Aplikasi ; Tampilan Yang Mudah. Hemat Waktu. Lintas Platform. Flaksible di segala device 
                    </p>
                    <div class="btn-box">
                      
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="img-box">
                    <img src="images/tekno.png" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item ">
            <div class="container ">
              <div class="row">
                <div class="col-md-6 ">
                  <div class="detail-box">
                    <h1>
                    Mengangkat Bisnis Anda ke Tingkat Berikutnya <br>
                    
                    </h1>
                    <p>
                    Apakah Anda ingin membuat keberadaan bisnis Anda lebih dikenal dan mudah diakses oleh pelanggan potensial? Apakah Anda ingin meningkatkan efisiensi operasional dan memperluas pangsa pasar Anda? Jawabannya sederhana: investasikan dalam jasa pembuatan website dan aplikasi profesional! Inilah solusi yang sempurna untuk memajukan bisnis Anda ke tingkat berikutnya.
                    </p>
                    <div class="btn-box">
                     
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="img-box">
                    <img src="images/tekno.png" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="container ">
              <div class="row">
                <div class="col-md-6 ">
                  <div class="detail-box">
                    <h1>
                    Keuntungan Membangun Website yang Profesional <br>
                    
                    </h1>
                    <p>
                     1.Tampilan yang Menarik dan Responsif
                     <br>
                     2.Pengalaman Pengguna yang Optimal
                     <br>
                     3.SEO-Friendly
                     <br>
                     4.Informasi yang Lengkap dan Mudah Diakses
                    </p>
                    <div class="btn-box">
                      
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="img-box">
                    <img src="images/tekno.png" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ol class="carousel-indicators">
          <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
          <li data-target="#customCarousel1" data-slide-to="1"></li>
          <li data-target="#customCarousel1" data-slide-to="2"></li>
        </ol>
      </div>

    </section>
    <!-- end slider section -->
  </div>


  <!-- service section -->

  <section class="service_section layout_padding" id="service">
    <div class="service_container">
      <div class="container ">
        <div class="heading_container heading_center">
          <h2>
             <span>Services</span>
          </h2>
          <p>
          Di Kazuya Media Indonesia peserta magang akan mempelajari
          </p>
        </div>
        <div class="row">
          <div class="col-md-4 ">
            <div class="box ">
              <div class="img-box">
                <img src="images/Laravel.jpg" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Laravel
                </h5>
                <p>
                Laravel adalah kerangka kerja aplikasi web berbasis PHP yang sumber terbuka, menggunakan konsep Model-View-Controller. Laravel berada dibawah lisensi MIT, dengan menggunakan GitHub sebagai tempat berbagi kode.
                </p>
                
              </div>
            </div>
          </div>
          <div class="col-md-4 ">
            <div class="box ">
              <div class="img-box">
                <img src="images/ci.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                 Codeigniter
                </h5>
                <p>
                CodeIgniter merupakan aplikasi sumber terbuka yang berupa kerangka kerja PHP dengan model MVC untuk membangun situs web dinamis dengan menggunakan PHP. CodeIgniter memudahkan pengembang web untuk membuat aplikasi web dengan cepat dan mudah.
                </p>
                
              </div>
            </div>
          </div>
          <div class="col-md-4 ">
            <div class="box ">
              <div class="img-box">
                <img src="images/react.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  React 
                </h5>
                <p>
                React adalah libray JavaScript yang digunakan untuk membangun user interface yang interaktif berbasis component. React yang dibuat oleh Facebook dan bersifat open-source, sehingga dapat digunakan oleh siapa saja secara gratis.
                </p>
                
                </a>
              </div>
            </div>
          </div>
        </div>
        <div class="btn-box">
          
        </div>
      </div>
    </div>
  </section>

  <!-- end service section -->


  <!-- about section -->

  <section class="about_section layout_padding" id="about">
    <div class="container  ">
      <div class="heading_container heading_center">
        <h2>
          <span>Requirements</span>
        </h2>
        <p>
          Persyaratan yang diperlukan untuk magang di kazuya media indonesia
        </p>
      </div>
      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/checklist1.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
<h3>
            <ul>
             <li> sopan, rajin, supel, senang bergaul, dan bernampilan rapi.</li>
             <br>
             <li> Minimal paham dasar html, css, javascript, query MySql.</li>
            </ul>    
</h3>       

          </div>
        </div>
      </div>
    </div>
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#FFFFFF" fill-opacity="1" d="M0,288L48,272C96,256,192,224,288,208C384,192,480,192,576,197.3C672,203,768,213,864,224C960,235,1056,245,1152,208C1248,171,1344,85,1392,42.7L1440,0L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
 

  <!-- end about section -->



  <!-- about section -->

  
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#FFFFFF" fill-opacity="1" d="M0,256L48,224C96,192,192,128,288,106.7C384,85,480,107,576,138.7C672,171,768,213,864,202.7C960,192,1056,128,1152,101.3C1248,75,1344,85,1392,90.7L1440,96L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path></svg>
    <div class="container  ">
      <div class="heading_container heading_center">
        <h2>
          <span>Benefit</span>
        </h2>
        <p>
          Benefit Yang Didapatkan Peserta Magang Kazuya Media Indonesia Adalah
        </p>
      </div>
      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/benefit.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
<h3>
            <ul>
             <li> berpeluang dapat pengarahan resource dengan design-pettern khusus / tingkat menengah.</li>
             <br>
             <li> berpeluang dapat pengarahan reactjs.</li>
             <br>
             <li> berpeluang dapat pengarahan / rekomendasi kerja di berbagai perusahaan ternama di masa mendatang.</li>
             <br>
             <li> berpeluang dapat panggilan kerjaan secara internal di kazuya media indo.</li>
             <br>
             <li> berpeluang dapat voucher pelatihan tertentu.</li>
             <br>

            </ul>    
</h3>       
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- why section -->

  <section class="why_section layout_padding" id="why">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Why Choose <span>Us</span>
        </h2>
      </div>
      <div class="why_container">
        <div class="box">
          <div class="img-box">
            <img src="images/w4.png" alt="">
          </div>
          <div class="detail-box">
            <h5>
              Profesional Teacher
            </h5>
            <p>
              Guru pembimbing magang profesional memiliki peran dalam memastikan kesejahteraan siswa selama magang. Mereka dapat membantu mengatasi masalah atau konflik yang mungkin timbul dan memastikan bahwa mahasiswa merasa nyaman dan mendukung di lingkungan kerja mereka.
            </p>
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/lingkungan.png" alt="">
          </div>
          <div class="detail-box">
            <h5>
              Lingkungan bersih & Nyaman
            </h5>
            <p>
              Lingkungan belajar yang bersih dan nyaman bukan hanya memfasilitasi pembelajaran yang efektif, tetapi juga membantu dalam pengembangan kesehatan mental dan kreativitas siswa. Dengan menciptakan ruang belajar yang kondusif, kita dapat meningkatkan pengalaman belajar siswa dan membantu mereka mencapai potensi maksimal mereka.
            </p>
          </div>
        </div>
        <div class="box">
          <div class="img-box">
            <img src="images/lokasi2.png" alt="">
          </div>
          <div class="detail-box">
            <h5>
              Tempat Strategis
            </h5>
            <p>
              Lokasi tempat magang berada di tempat yang strategis. Di barat tempat magang adalah jl pramuka, dimana di jl pramuka banyak makanan dan jajan jajanan sehingga tidak perlu khawatir tentang makanan, di sekitar tempat magang juga terdapat masjid yang bersih dan nyaman.
            </p>
          </div>
        </div>
      </div>
      <div class="btn-box">
        
      </div>
    </div>
  </section>

  <!-- end why section -->

  <!-- team section -->
  <section class="team_section layout_padding" id="team">
    <div class="container-fluid">
      <div class="heading_container heading_center">
        <h2 class="">
           <span> Team</span>
        </h2>
      </div>

      <div class="team_container">
        <div class="row">
          <div class="col-lg-4 col-sm-6">
            <div class="box ">
              <div class="img-box">
                <img src="images/team-1.jpg" class="img1" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Fatoni
                </h5>
                <p>
                  Staff
                </p>
              </div>
              <div class="social_box">
                <a href="#">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube-play" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="box ">
              <div class="img-box">
                <img src="images/team-1.jpg" class="img1" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Arif
                </h5>
                <p>
                  Owner
                </p>
              </div>
              <div class="social_box">
                <a href="#">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube-play" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </div>
          <div class="col-lg-4 col-sm-6">
            <div class="box ">
              <div class="img-box">
                <img src="images/team-1.jpg" class="img1" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Habli
                </h5> 
                <p>
                  Staff
                </p>
              </div>
              <div class="social_box">
                <a href="#">
                  <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-linkedin" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
                <a href="#">
                  <i class="fa fa-youtube-play" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end team section -->


  <!-- client section -->

  <section class="client_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center psudo_white_primary mb_45">
        <h2>
          What says our <span>Customers</span>
        </h2>
      </div>
      <div class="carousel-wrap ">
        <div class="owl-carousel client_owl-carousel">
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/client1.jpg" alt="" class="box-img">
              </div>
              <div class="detail-box">
                <div class="client_id">
                  <div class="client_info">
                    <h6>
                      LusDen
                    </h6>
                    <p>
                      magna aliqua. Ut
                    </p>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/client2.jpg" alt="" class="box-img">
              </div>
              <div class="detail-box">
                <div class="client_id">
                  <div class="client_info">
                    <h6>
                      Zen Court
                    </h6>
                    <p>
                      magna aliqua. Ut
                    </p>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/client1.jpg" alt="" class="box-img">
              </div>
              <div class="detail-box">
                <div class="client_id">
                  <div class="client_info">
                    <h6>
                      LusDen
                    </h6>
                    <p>
                      magna aliqua. Ut
                    </p>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="img-box">
                <img src="images/client2.jpg" alt="" class="box-img">
              </div>
              <div class="detail-box">
                <div class="client_id">
                  <div class="client_info">
                    <h6>
                      Zen Court
                    </h6>
                    <p>
                      magna aliqua. Ut
                    </p>
                  </div>
                  <i class="fa fa-quote-left" aria-hidden="true"></i>
                </div>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end client section -->


  <!-- info section -->

  <section class="info_section layout_padding2">
    <div class="container">
      <div class="row">
        <div class="col-md-6 col-lg-3 info_col">
          <div class="info_contact">
            <h4>
              Address
            </h4>
            <div class="contact_link_box">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Location
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call +01 1234567890
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  demo@gmail.com
                </span>
              </a>
            </div>
          </div>
          <div class="info_social">
            <a href="">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 info_col">
          <div class="info_detail">
            <h4>
              Info
            </h4>
            <p>
              necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful
            </p>
          </div>
        </div>
        <div class="col-md-6 col-lg-2 mx-auto info_col">
          <div class="info_link_box">
            <h4>
              Links
            </h4>
            <div class="info_links">
              <a class="active" href="index.html">
                Home
              </a>
              <a class="" href="about.html">
                About
              </a>
              <a class="" href="service.html">
                Services
              </a>
              <a class="" href="why.html">
                Why Us
              </a>
              <a class="" href="team.html">
                Team
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3 info_col ">
          <h4>
            Subscribe
          </h4>
          <form action="#">
            <input type="text" placeholder="Enter email" />
            <button type="submit">
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->