<body class="">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg position-absolute top-0 z-index-3 w-100 shadow-none my-3 navbar-transparent mt-4">
    <div class="container">
      <a class="navbar-brand font-weight-bolder ms-lg-0 ms-3 text-white" href="<?= base_url(); ?>assets_admin/pages/dashboard.html">
        Registration
      </a>
      <button class="navbar-toggler shadow-none ms-2" type="button" data-bs-toggle="collapse" data-bs-target="#navigation" aria-controls="navigation" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon mt-2">
          <span class="navbar-toggler-bar bar1"></span>
          <span class="navbar-toggler-bar bar2"></span>
          <span class="navbar-toggler-bar bar3"></span>
        </span>
      </button>
      <div class="collapse navbar-collapse" id="navigation">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            
          </li>
          <li class="nav-item">
            
          </li>
          <li class="nav-item">
            
          </li>
          <li class="nav-item">
            
          </li>
        </ul>
        <ul class="navbar-nav d-lg-block d-none">
         
        </ul>
      </div>
    </div>
  </nav>
  <!-- End Navbar -->
  <main class="main-content  mt-0">
    <div class="page-header align-items-start min-vh-50 pt-5 pb-11 m-3 border-radius-lg" style="background-image: url('https://raw.githubusercontent.com/creativetimofficial/public-assets/master/argon-dashboard-pro/assets/img/signup-cover.jpg'); background-position: top;">
      <span class="mask bg-gradient-dark opacity-6"></span>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-5 text-center mx-auto">
            <h1 class="text-white mb-2 mt-5">Welcome!</h1>
            <p class="text-lead text-white">Use these awesome forms to login or create new account in your project for free.</p>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row mt-lg-n10 mt-md-n11 mt-n10 justify-content-center">
        <div class="col-xl-4 col-lg-5 col-md-7 mx-auto">
          <div class="card z-index-0">
            
            <div class="card-header text-center pt-4">
              <h5>Register</h5>
            </div>
            <div class="row px-xl-5 px-sm-4 px-3">
              
              
              <div class="mt-2 position-relative text-center">
                
              </div>
            </div>
            <div class="card-body">

            <?php echo form_open('C_regis/input_simpan'); ?>
            <?php $atribut = ['method'=>'post'];echo form_open('C_regis/input_simpan',$atribut); ?>
              <form id="contactForm" data-sb-form-api-token="API_TOKEN">
                <div class="mb-3">
                  <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama" aria-label="nama"  data-sb-validations="required">
                </div>
                <div class="mb-3">
                  <input type="text" id="idkelas" name="idkelas" class="form-control" placeholder="Kelas" aria-label="idkelas">
                </div>
                <div class="mb-3">
                  <input type="text" id="alamat" name="alamat" class="form-control" placeholder="Alamat" aria-label="alamat">
                </div>
                <div class="mb-3">
                  <input type="text" id="no_hp" name="no_hp" class="form-control" placeholder="No HP" aria-label="nohp">
                </div>
                <div class="mb-3">
                  <input type="text" id="idsekolah" name="idsekolah" class="form-control" placeholder="Sekolah" aria-label="sekolah">
                </div>
                <div style="column-count: 3;">
                <h5>  CV </h5>
                <input type="file" name="avatar" id="avatar" accept="image/png, image/jpeg, image/jpg, image/gif">
                </div>
                <br>
               
                <a  href="https://cms.dailysocial.id/wp-content/uploads/2022/10/cv1.jpg"> Downloads Example </a>

                 
                  
                </div>
                <div class="text-center">
                  <button type="submit" class="btn bg-gradient-dark w-100 my-4 mb-2">Sign up</button>
                </div>
                
              </form>
              <?php echo form_close();?> 
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>