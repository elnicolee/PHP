<!DOCTYPE html>
<html>
<head>
    <title>Formulir Pendaftaran Siswa Baru | SMK Coding</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    
    
    
</head>

<body>


    <div class="container">
    <form action="proses-pendaftaran.php" method="POST" class="login-email" enctype="multipart/form-data">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Registration</p>
            
            <div class="input-group">
                <input type="text" placeholder="Nama" name="nama" value="" required>
            </div>

            <div class="input-group">
                <input type="text" placeholder="Alamat" name="alamat" value="" required>
            </div>

            <p>
            <label for="jenis_kelamin">Jenis Kelamin: </label>
            <label><input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki</label>
            <label><input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan</label>
            </p>
            <br>
            <p>
            <label for="agama">Agama: </label>
            <select class="form-select" aria-label="Default select example" name="agama">
                <option>Islam</option>
                <option>Kristen</option>
                <option>Hindu</option>
                <option>Budha</option>
                <option>Atheis</option>
            </select>
        </p>
        <br>
            <div class="input-group">
                <input type="text" placeholder="Asal Sekolah" name="sekolah_asal" value="" required>
            </div>
            
            <label for="jenis_kelamin">Tanggal Lahir: </label>
            <input type="date" value="" name="tanggal_lahir">
            <br>
            <br>

            <div class="input-group">
                <input type="text" placeholder="Nomor Telp" name="nomer_tlp" value="" required>
            </div>

            <label for="img">Select Photo:</label>
            <input type="file" id="img" name="img" accept="image/*">
            <br>
            <br>

            <div class="input-group">
                <button type="submit" value="Daftar" name="daftar" class="btn">SIMPAN</button>
            </div>

            
        </form>
    </div> 
   
</body>
<!-- <--!XIXIXIXIXIIX
    <form action="proses-pendaftaran.php" method="POST">

        <fieldset>

        <p>
            <label for="nama">Nama: </label>
            <input type="text" name="nama" placeholder="nama lengkap" />
        </p>
        <p>
            <label for="alamat">Alamat: </label>
            <textarea name="alamat"></textarea>
        </p>
        <p>
            <label for="jenis_kelamin">Jenis Kelamin: </label>
            <label><input type="radio" name="jenis_kelamin" value="laki-laki"> Laki-laki</label>
            <label><input type="radio" name="jenis_kelamin" value="perempuan"> Perempuan</label>
        </p>
        <p>
            <label for="agama">Agama: </label>
            <select name="agama">
                <option>Islam</option>
                <option>Kristen</option>
                <option>Hindu</option>
                <option>Budha</option>
                <option>Atheis</option>
            </select>
        </p>
        <p>
            <label for="sekolah_asal">Sekolah Asal: </label>
            <input type="text" name="sekolah_asal" placeholder="nama sekolah" />
        </p>
        <p>
            <input type="submit" value="Daftar" name="daftar" />
        </p>

        </fieldset>

    </form>

    </body>
</html> -->