<?php

include("config.php");

// kalau tidak ada id di query string
if( !isset($_GET['id']) ){
    header('Location: list-siswa.php');
}

//ambil id dari query string
$id = $_GET['id'];

// buat query untuk ambil data dari database
$sql = "SELECT * FROM calon_siswa WHERE id=$id";
$query = mysqli_query($db, $sql);
$siswa = mysqli_fetch_assoc($query);

// jika data yang di-edit tidak ditemukan
if( mysqli_num_rows($query) < 1 ){
    die("data tidak ditemukan...");
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Formulir Edit Siswa | SMK Coding</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
<div class="container">

    <form action="proses-edit.php" method="POST" class="login-email" enctype="multipart/form-data">

    <p class="login-text" style="font-size: 2rem; font-weight: 800;">Edit Data</p>
    
            <input type="hidden" name="id" value="<?php echo $siswa['id'] ?>" />
    
            <div class="input-group">
            <input type="text" name="nama" placeholder="nama lengkap" value="<?php echo $siswa['nama'] ?>" />
            </div>

            <div class="input-group">
            <input type="text" name="alamat" placeholder="alamat" value="<?php echo $siswa['alamat'] ?>" />
        </div>

        <p>
            <label for="jenis_kelamin">Jenis Kelamin: </label>
            <?php $jk = $siswa['jenis_kelamin']; ?>
            <label><input type="radio" name="jenis_kelamin" value="laki-laki" <?php echo ($jk == 'laki-laki') ? "checked": "" ?>> Laki-laki</label>
            <label><input type="radio" name="jenis_kelamin" value="perempuan" <?php echo ($jk == 'perempuan') ? "checked": "" ?>> Perempuan</label>
        </p>

        
        <br>
        <p>
            <label for="agama">Agama: </label>
            <?php $agama = $siswa['agama']; ?>
            <select name="agama">
                <option <?php echo ($agama == 'Islam') ? "selected": "" ?>>Islam</option>
                <option <?php echo ($agama == 'Kristen') ? "selected": "" ?>>Kristen</option>
                <option <?php echo ($agama == 'Hindu') ? "selected": "" ?>>Hindu</option>
                <option <?php echo ($agama == 'Budha') ? "selected": "" ?>>Budha</option>
                <option <?php echo ($agama == 'Atheis') ? "selected": "" ?>>Atheis</option>
            </select>
        </p>

        <br>
        
        <div class="input-group">
            <input type="text" name="sekolah_asal" placeholder="nama sekolah" value="<?php echo $siswa['sekolah_asal'] ?>" />
        </div>

        <label for="jenis_kelamin">Tanggal Lahir: </label>
        <input type="date" value="<?php echo $siswa['tanggal_lahir'] ?>" name="tanggal_lahir">
        <br>
        <br>
        <div class="input-group">
            <input type="text" name="nomer_tlp" placeholder="alamat" value="<?php echo $siswa['nomer_tlp'] ?>" />
        </div>

        <label for="img">Select Photo:</label>
            <input type="file" id="img" name="img" accept="image/*">

            <br>
            <br>
            <div class="input-group">
                <button type="submit" value="Simpan" name="simpan" class="btn">SIMPAN</button>
            </div>
        <!-- <p>
            <input type="submit" value="Simpan" name="simpan" />
        </p> -->

       


    </form>
</div>
    </body>
</html>