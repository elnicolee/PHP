<?php

include("config.php");

// cek apakah tombol daftar sudah diklik atau blum?
if(isset($_POST['daftar'])){

    // ambil data dari formulir
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $agama = $_POST['agama'];
    $sekolah_asal = $_POST['sekolah_asal'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $nomer_tlp = $_POST['nomer_tlp'];
    $foto = $_FILES['img'];

// Proses tambahan untuk gambar
$nama_file = $_FILES['img']['name'];
$lokasi_file = $_FILES['img']['tmp_name'];
$folder = "foto/";

if (move_uploaded_file($lokasi_file, $folder . $nama_file)) {
    // Gambar berhasil diunggah, simpan nama file ke database
    $sql = "INSERT INTO calon_siswa (nama, alamat, jenis_kelamin, agama, sekolah_asal, tanggal_lahir, nomer_tlp, foto) VALUES ('$nama', '$alamat', '$jenis_kelamin', '$agama', '$sekolah_asal', '$tanggal_lahir', '$nomer_tlp', '$nama_file')";
    $query = mysqli_query($db, $sql);

     // Lakukan pengecekan untuk memastikan query berhasil dieksekusi
     if ($query) {
        // Redirect ke halaman index jika query berhasil
        header("Location: index.php");
        exit; // Penting untuk menghentikan eksekusi skrip setelah melakukan redirect
    } else {
        echo "Terjadi kesalahan dalam penyimpanan data siswa.";
    }
} else {
    echo "Terjadi kesalahan saat mengunggah gambar.";
}

} else {
die("Akses dilarang...");
}

?>