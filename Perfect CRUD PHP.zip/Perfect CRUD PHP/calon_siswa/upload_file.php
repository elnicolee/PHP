<?php
    $message = '';
    $uploadDir = 'uploads/';
    $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');

    // Koneksi ke database MySQL
    $dbHost = 'localhost';
    $dbUsername = 'username';
    $dbPassword = 'password';
    $dbName = 'database_name';

    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    if ($conn->connect_error) {
        die("Koneksi ke database gagal: " . $conn->connect_error);
    }

    if(isset($_POST['upload'])){
        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES['file']['size'];
        $fileType = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if(in_array($fileType, $allowedTypes)){
            $uploadPath = $uploadDir . basename($fileName);

            if(move_uploaded_file($fileTmpName, $uploadPath)){
                // Simpan informasi file ke database
                $insertQuery = "INSERT INTO uploaded_files (file_name, file_size, file_type) VALUES ('$fileName', $fileSize, '$fileType')";
                if ($conn->query($insertQuery) === TRUE) {
                    $message = 'File berhasil diunggah dan informasi telah disimpan ke database.';
                } else {
                    $message = 'Terjadi kesalahan saat menyimpan informasi file ke database.';
                }
            } else {
                $message = 'Terjadi kesalahan saat mengunggah file.';
            }
        } else {
            $message = 'Hanya file dengan ekstensi JPG, JPEG, PNG, dan GIF yang diizinkan untuk diunggah.';
        }
    }
?>
