<?php

require_once '../lib/Database.php';
header('Content-Type: application/json; charset=utf-8');

class Item {

    public $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function index()
    {
        $this->db->query("SELECT * FROM items");
        $data = $this->db->resultSet();
        
        echo json_encode($data);
    }

    public function show($id)
    {
        $this->db->query("SELECT * FROM items WHERE id=:id");
        $this->db->bind('id', $id);
        $data = $this->db->resultRow();
        
        echo json_encode($data);
    }

    public function store()
    {
        // get and parsing data body
        $bodyParams = file_get_contents('php://input');
        $bodyParams = json_decode($bodyParams);

        $sql = "
            INSERT INTO items VALUES ('', :item, :category, :keterangan, :harga)
        ";
        $this->db->query($sql);
        $this->db->bind('item', $bodyParams->item);
        $this->db->bind('category', $bodyParams->category);
        $this->db->bind('keterangan', $bodyParams->keterangan);
        $this->db->bind('harga', $bodyParams->harga);
        $this->db->execute();

        echo json_encode([
            'success' => true
        ]);
    }

    public function update($id)
    {
        // get and parsing data body
        $bodyParams = file_get_contents('php://input');
        $bodyParams = json_decode($bodyParams);

        $this->db->query("SELECT * FROM items WHERE id=:id");
        $this->db->bind('id', $id);
        $item = $this->db->resultRow();

        if (!$item) {
            echo json_encode([
                'success' => false,
                'message' => 'Data item not found'
            ]);
        }

        $sql = "
            UPDATE items SET item = :item, category = :category, 
            keterangan = :keterangan, harga = :harga
            WHERE id = :id
        ";
        $this->db->query($sql);
        $this->db->bind('id', $id);
        $this->db->bind('item', $bodyParams->item ?: $item['body']);
        $this->db->bind('category', $bodyParams->category ?: $item['category']);
        $this->db->bind('keterangan', $bodyParams->keterangan ?: $item['keterangan']);
        $this->db->bind('harga', $bodyParams->harga ?: $item['harga']);
        $this->db->execute();

        echo json_encode([
            'success' => true
        ]);
    }

    public function delete($id)
    {
        // get and parsing data body
        // $bodyParams = file_get_contents('php://input');
        // $bodyParams = json_decode($bodyParams);

        $sql = "DELETE FROM items WHERE id = :id";
		$this->db->query($sql);
		$this->db->bind('id', $id);
        $this->db->execute();

        echo json_encode([
            'success' => true
        ]);
    }
}

$route = isset($_GET['route']) ? $_GET['route'] : null;
$id = isset($_GET['id']) ? $_GET['id'] : null;

if ($route === null) {
    echo json_encode([
        'success' => false,
        'message' => 'Route not found'
    ]);
}

$item = new Item();
if ($id) {
    $item->{$route}($id);
} else {
    $item->{$route}();
}