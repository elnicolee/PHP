<?php
$host = 'localhost';  // Ganti dengan host MySQL Anda, misal 'localhost'
$username = 'root';   // Ganti dengan username MySQL Anda
$password = '';       // Ganti dengan password MySQL Anda
$dbname = 'todo_list'; // Nama database yang sudah dibuat

// Koneksi ke MySQL
$conn = new mysqli($host, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>