<?php
include('config.php');

// Mengambil ID dari URL
$id = $_GET['id'];

// Hapus tugas
$sql = "DELETE FROM tasks WHERE id = $id";
if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>