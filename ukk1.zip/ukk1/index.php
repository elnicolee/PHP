<?php
include('config.php');

// Menambahkan tugas baru
if (isset($_POST['add_task'])) {
    $task = $_POST['task'];
    $sql = "INSERT INTO tasks (task) VALUES ('$task')";
    if ($conn->query($sql) === TRUE) {
        echo "Tugas berhasil ditambahkan!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Mengambil data tugas yang belum selesai
$sql_incomplete = "SELECT * FROM tasks WHERE status = 'incomplete' ORDER BY created_at DESC";
$result_incomplete = $conn->query($sql_incomplete);

// Mengambil data tugas yang sudah selesai
$sql_complete = "SELECT * FROM tasks WHERE status = 'complete' ORDER BY created_at DESC";
$result_complete = $conn->query($sql_complete);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <!-- Menambahkan Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h1 class="text-center mb-4">To-Do List</h1>

        <!-- Formulir untuk menambahkan tugas baru -->
        <form method="POST" action="index.php" class="d-flex mb-4">
            <input type="text" name="task" class="form-control me-2" placeholder="Masukkan tugas baru" required>
            <button type="submit" name="add_task" class="btn btn-primary">Tambah Tugas</button>
        </form>

        <!-- Daftar Tugas yang Belum Selesai -->
        <h2>Tugas yang Belum Selesai</h2>
        <div class="row">
            <?php while($row = $result_incomplete->fetch_assoc()) { ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $row['task']; ?></h5>
                            <div class="d-flex justify-content-between">
                                <a href="update.php?id=<?php echo $row['id']; ?>&status=complete" class="btn btn-success btn-sm">Tandai Selesai</a>
                                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>

        <!-- Daftar Tugas yang Sudah Selesai -->
        <h2>Tugas yang Sudah Selesai</h2>
        <div class="row">
            <?php while($row = $result_complete->fetch_assoc()) { ?>
                <div class="col-md-4 mb-4">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h5 class="card-title text-decoration-line-through text-muted"><?php echo $row['task']; ?></h5>
                            <div class="d-flex justify-content-between">
                                <a href="update.php?id=<?php echo $row['id']; ?>&status=incomplete" class="btn btn-warning btn-sm">Tandai Belum Selesai</a>
                                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>

    <!-- Menambahkan Bootstrap JS dan Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
