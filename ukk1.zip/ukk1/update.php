<?php
include('config.php');

// Mengambil ID dan status dari URL
$id = $_GET['id'];
$status = $_GET['status'];

// Update status tugas
$sql = "UPDATE tasks SET status = '$status' WHERE id = $id";
if ($conn->query($sql) === TRUE) {
    header('Location: index.php');
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
?>